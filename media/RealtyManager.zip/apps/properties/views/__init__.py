from .property_list import PropertyListCreateView
from .property_detail import PropertyDetailView